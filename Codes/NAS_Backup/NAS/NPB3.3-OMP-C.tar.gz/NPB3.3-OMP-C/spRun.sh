cd ./bin/
rm sp.A.bc
rm sp.A
cd ../SP/
make clean
cd ../
make sp CLASS=A
cd bin/
/home/norouzi/Desktop/software/llvmTemp/build/bin/clang++ -fopenmp sp.A.bc -o sp.A
./sp.A
