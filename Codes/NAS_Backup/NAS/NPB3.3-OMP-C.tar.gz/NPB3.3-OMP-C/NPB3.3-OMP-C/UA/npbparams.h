/* CLASS = S */
/*
   This file is generated automatically by the setparams utility.
   It sets the number of processors and the class of the NPB
   in this directory. Do not modify it by hand.   
*/
#define LELT           250

#define LMOR           11600

#define REFINE_MAX     4

#define FRE_DEFAULT    5

#define NITER_DEFAULT  50

#define NMXH_DEFAULT   10

#define CLASS_DEFAULT  'S'

#define ALPHA_DEFAULT  0.040e0


#define CONVERTDOUBLE  false
#define COMPILETIME "25 Feb 2016"
#define NPBVERSION "3.3.1"
#define CS1 "(none)"
#define CS2 "(none)"
#define CS3 "(none)"
#define CS4 "-I ../common -I /home/norouzi/Desktop/softw..."
#define CS5 "(none)"
#define CS6 "(none)"
#define CS7 "randdp"
