#define CLASS 'S'
/*
   This file is generated automatically by the setparams utility.
   It sets the number of processors and the class of the NPB
   in this directory. Do not modify it by hand.   */
   
#define COMPILETIME "04 Mar 2016"
#define NPBVERSION "3.3.1"
#define CC "(none)"
#define CFLAGS "(none)"
#define CLINK "(none)"
#define CLINKFLAGS "(none)"
#define C_LIB "(none)"
#define C_INC "-I ../common -I /home/norouzi/Desktop/softw..."
