#define CLASS 'S'
/*
   This file is generated automatically by the setparams utility.
   It sets the number of processors and the class of the NPB
   in this directory. Do not modify it by hand.
   This file provided for backward compatibility.
   It is not used in DC benchmark.   */
   
long long int input_tuples=1000, attrnum=5;
#define COMPILETIME "25 Feb 2016"
#define NPBVERSION "3.3.1"
#define CC "(none)"
#define CFLAGS "(none)"
#define CLINK "(none)"
#define CLINKFLAGS "(none)"
#define C_LIB "(none)"
#define C_INC "-I ../common -I /home/norouzi/Desktop/softw..."
