cd ./bin/
rm mg.A.bc
rm mg.A
cd ../MG/
make clean
cd ../
make mg CLASS=A
cd bin/
/home/norouzi/Desktop/software/llvmTemp/build/bin/clang++ -fopenmp mg.A.bc -o mg.A
./mg.A
