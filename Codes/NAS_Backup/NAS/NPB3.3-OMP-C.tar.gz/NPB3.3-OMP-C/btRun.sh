cd ./bin/
rm bt.A.bc
rm bt.A
cd ../BT/
make clean
cd ../
make bt CLASS=A
cd bin/
/home/norouzi/Desktop/software/llvmTemp/build/bin/clang++ -fopenmp bt.A.bc -o bt.A
./bt.A
