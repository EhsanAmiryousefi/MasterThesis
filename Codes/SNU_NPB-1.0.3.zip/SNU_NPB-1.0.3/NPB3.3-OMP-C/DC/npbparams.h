#define CLASS 'W'
/*
   This file is generated automatically by the setparams utility.
   It sets the number of processors and the class of the NPB
   in this directory. Do not modify it by hand.
   This file provided for backward compatibility.
   It is not used in DC benchmark.   */
   
long long int input_tuples=100000, attrnum=10;
#define COMPILETIME "10 Jul 2013"
#define NPBVERSION "3.3.1"
#define CC "gcc"
#define CFLAGS "-g -Wall -O3 -fopenmp -mcmodel=medium"
#define CLINK "$(CC)"
#define CLINKFLAGS "-O3 -fopenmp -mcmodel=medium"
#define C_LIB "-lm"
#define C_INC "-I../common"
